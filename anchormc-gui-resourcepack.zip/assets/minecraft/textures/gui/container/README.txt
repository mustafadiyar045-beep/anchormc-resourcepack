AnchorMC GUI Container Textures
================================
inventory.png     - Oyuncu envanteri (E tuşu)
generic_54.png    - Sandık / büyük konteyner

Tema: Koyu lacivert zemin + Altın kenarlık
Renk paleti:
  Altın:   #FFD700 / #C8A000
  Zemin:   #08080F / #0E0B18
  Kenarlık: #55420A
